var Script = function () {


//    tool tips

    $('.tooltips').tooltip();

//    popovers

    $('.popovers').popover();

//    bxslider

    $('.bxslider').show();
     $('.bxslider').bxSlider({
         minSlides: 4,
         maxSlides: 4,
        slideWidth: 276,
        slideMargin: 20
     });

}();

	(function() {


	    $('<i id="menu-portfolio"></i>').appendTo($('body'));

			$(window).scroll(function() {

				if($(this).scrollTop() != 0) {
					$('#menu-portfolio').fadeIn();
				} else {
					$('#menu-portfolio').fadeOut();
				}

			});

			$('#menu-portfolio').click(function() {
				$('#portfolio').toggle();
				$('#portfoliod').toggle();
				$('#tree').fadeOut();
				$('#three').fadeOut();
				$("html, body").animate({scrollTop: $('#smooth3').offset().top }, 600);
			});



	    $('<i id="menu-contact"></i>').appendTo($('body'));

			$(window).scroll(function() {

				if($(this).scrollTop() != 0) {
					$('#menu-contact').fadeIn();
				} else {
					$('#menu-contact').fadeOut();
				}

			});

			$('#menu-contact').click(function() {
				$('#three').toggle();
				$('#tree').fadeOut();
				$('#portfolio').fadeOut();
				$('#portfoliod').fadeOut();
				$("html, body").animate({scrollTop: $('#three').offset().top }, 600);
			});



	     $(window).scroll(function() {

				if($(this).scrollTop() != 0) {
					$('#banner').fadeOut();
				} else {
					$('#banner').fadeIn();
				}

			});



			$('<i id="menu-widget"></i>').appendTo($('body'));

			$(window).scroll(function() {

				if($(this).scrollTop() != 0) {
					$('#menu-widget').fadeIn();
				} else {
					$('#menu-widget').fadeOut();
				}

			});

			$('#menu-widget').click(function() {
				$('#tree').toggle();
				$('#three').fadeOut();
				$('#portfolio').fadeOut();
				$('#portfoliod').fadeOut();
				$("html, body").animate({scrollTop: $('#tree').offset().top }, 600);
			});





   			$('<i id="back-to-top"></i>').appendTo($('body'));

			$(window).scroll(function() {

				if($(this).scrollTop() != 0) {
					$('#back-to-top').fadeIn();
				} else {
					$('#back-to-top').fadeOut();
					$('#tree').fadeOut();
				    $('#three').fadeOut();
				}

			});

			$('#back-to-top').click(function() {
			    $('#tree').fadeOut();
				$('#three').fadeOut();
				$('body,html').animate({scrollTop:0},600);
			});

	})();

