from django.test import TestCase                                                
from sekizai.context import SekizaiContext                                      

from cms.api import add_plugin                                                  
from cms.models import Placeholder  
# Put class def here

def test_plugin(self):                                               
    placeholder = Placeholder.objects.create(slot='test')                   
    model_inst = add_plugin(placeholder,                                    
        cms_plugins.MyPlugin, 'en')                     
    context = SekizaiContext()                                              

    html = model_inst.render_plugin     (context=context)                                                                                    
    self.assertTrue(len(html) > 0) 
