

import os
import sys


path = '/root/Bureau/secretRaidenMotion/fidoteamProject'
sys.path.append('/root/.virtualenvs/envRaiden/lib/python3.5/site-packages')
sys.path.append('/usr/share/lib/python3.5/site-packages')

activate_env=os.path.expanduser('/root/.virtualenvs/envRaiden/bin/activate_this.py')
try:
    execfile(activate_env, dict(__file__=activate_env))
except:
    pass

if path not in sys.path:
    sys.path.append(path)

os.environ['DJANGO_SETTINGS_MODULE'] = 'fidoteamProject.settings'
from django.contrib.sitemaps import ping_google
try:
    ping_google()
except Exception:
 # Bare 'except' because we could get a variety
 # of HTTP-related exceptions.
 pass



from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()




